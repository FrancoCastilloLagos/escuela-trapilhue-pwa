PROYECTO: Plataforma de comunicación y gestión académica Escuela Trapilhue 
ESTUDIANTE: Franco Castillo Lagos 
CARRERA: Analista Programador

1. Estructura de la base de datos
La base de datos se denomina escuela_trapilhue. Está diseñada para soportar un entorno educativo con gestión de notas, convivencia escolar y un sistema de notificaciones en tiempo real. Se compone de las siguientes entidades principales:

usuario: Gestión de seguridad y acceso (RUT y password).
docente / apoderado: Tablas que extienden el perfil del usuario según su rol.
curso / asignatura: Estructura académica de la institución.
estudiante: Ficha del alumno, vinculada a un curso y a un tutor (apoderado).
nota / evaluacion: Registro detallado de calificaciones y exámenes.
anotacion: Registro de comportamiento (Convivencia Escolar).
notificaciones: Sistema de alertas para usuarios según cambios en notas o comunicaciones.
sincronizacion: Tabla técnica para el control de datos en modo offline (PWA).

2. Relaciones Principales
El modelo implementa integridad referencial avanzada mediante Constraints:

notificaciones -> usuario: Relación (1:N) vinculada por id_usuario. Implementa ON DELETE CASCADE para asegurar que al eliminar un usuario se limpien sus alertas.
estudiante -> curso / apoderado: Relaciones que permiten la trazabilidad del alumno con su grupo académico y su responsable legal.
anotacion / nota -> estudiante: Vinculación directa para la generación de historiales de rendimiento y conducta.

3. Instrucciones de Ejecución de Scripts
Para levantar la base de datos de manera exitosa, siga este orden:

Creación del schema: Ejecute el comando: CREATE DATABASE escuela_trapilhue;

Uso de la base de datos: Seleccione el esquema antes de proceder: USE escuela_trapilhue;

Ejecución de la estructura: Cargue y ejecute el archivo 1_creacion_tablas.sql.

Ejecución de carga de datos: Cargue y ejecute el archivo 2_carga_datos.sql. Este archivo contiene los INSERT con los datos de prueba para docentes, alumnos y cursos necesarios para testear la plataforma. y de prueba necesarios para el funcionamiento del sistema.